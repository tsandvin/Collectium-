# Collectium

Collectium er en AI-basert plattform for samleobjekter. Systemet skal håndtere medlemmer, forhandlere, samleobjekter, bilder, objektlogg, auksjon, historikk, verdivurdering og AI-søk.

## Formål

Dette repositoryet er laget som en programmeringsmal for Collectium. Det skal gi en tydelig struktur for frontend, backend, database, sikkerhet og videre AI-assistert utvikling.

## Teknologistack

- Frontend: React
- Styling: Tailwind CSS
- Backend: PHP REST API
- Database: MySQL
- Autentisering: OAuth / JWT
- Filhåndtering: bildeopplasting og objektreferanser
- AI: bildeanalyse, tekstsøk og relasjonsbasert objektmatching

## Hovedmoduler

- Dashboard
- Mine samleobjekter
- Objektregister
- Objektprofil
- Medlemmer
- Forhandlere
- Auksjon
- AI-søk
- Adminpanel
- Logg og historikk

## Bruk

1. Opprett nytt GitHub-repository.
2. Last opp innholdet i denne mappen.
3. Kopier `.env.example` til `.env` lokalt.
4. Sett databaseverdier og OAuth-nøkler.
5. Bruk `docs/collectium-ai-developer-instructions.md` som fast instruks til AI-verktøy som Cursor, Claude, ChatGPT eller Emergent.

## Viktig sikkerhet

- Ikke legg API-nøkler i GitHub.
- Ikke commit `.env`.
- Bruk rollebasert tilgang.
- Alle API-endepunkter skal validere brukerrolle.
- Alle databasekall skal bruke prepared statements.
