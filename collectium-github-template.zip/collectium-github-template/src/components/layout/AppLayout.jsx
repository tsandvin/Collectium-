import Sidebar from '../sidebar/Sidebar';

export default function AppLayout({ children }) {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <div className="flex min-h-screen">
        <Sidebar />
        <div className="flex-1 overflow-auto">
          <header className="sticky top-0 z-10 border-b bg-white/90 backdrop-blur">
            <div className="flex h-16 items-center justify-between px-6">
              <div className="font-semibold">Collectium</div>
              <div className="flex items-center gap-3">
                <input className="rounded-xl border px-3 py-2 text-sm" placeholder="Søk i objekter..." />
                <div className="h-9 w-9 rounded-full bg-gray-200" />
              </div>
            </div>
          </header>
          {children}
        </div>
      </div>
    </div>
  );
}
