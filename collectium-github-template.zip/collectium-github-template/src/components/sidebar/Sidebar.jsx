const menuItems = [
  'Dashboard',
  'Mine objekter',
  'Objektregister',
  'AI-søk',
  'Auksjon',
  'Forhandler',
  'Medlemmer',
  'Admin'
];

export default function Sidebar() {
  return (
    <aside className="hidden w-72 shrink-0 border-r bg-white p-4 md:block">
      <div className="mb-6 text-xl font-bold">Collectium</div>
      <nav className="space-y-1">
        {menuItems.map((item) => (
          <button
            key={item}
            className="w-full rounded-xl px-3 py-2 text-left text-sm hover:bg-gray-100"
          >
            {item}
          </button>
        ))}
      </nav>
    </aside>
  );
}
