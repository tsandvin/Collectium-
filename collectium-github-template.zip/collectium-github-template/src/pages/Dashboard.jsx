export default function Dashboard() {
  return (
    <main className="p-6 space-y-6">
      <section>
        <h1 className="text-2xl font-semibold">Collectium Dashboard</h1>
        <p className="text-sm text-gray-600">Oversikt over samlinger, objekter, verdi og aktivitet.</p>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl border p-4 shadow-sm">Mine objekter</div>
        <div className="rounded-2xl border p-4 shadow-sm">Estimert verdi</div>
        <div className="rounded-2xl border p-4 shadow-sm">Aktive auksjoner</div>
      </section>
    </main>
  );
}
