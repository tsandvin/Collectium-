# Database Structure

Denne filen beskriver hovedtabellene i Collectium.

## users

Lagrer brukere, innlogging og rolle.

## memberships

Lagrer abonnementstype, status, startdato og utløpsdato.

## dealers

Lagrer forhandlerprofil, godkjenningsstatus og offentlig presentasjon.

## collectible_objects

Kjernetabell for alle samleobjekter.

Eksempler:

- mynter
- sedler
- frimerker
- kunst
- klokker
- historiske objekter

## object_images

Lagrer bilder knyttet til objekter.

## object_logs

Lagrer historikk: opprettet, endret, solgt, overført, verdivurdert, auksjonert.

## object_valuations

Lagrer verdivurderinger, kilde, valuta, KPI-justering og markedsverdi.

## auctions og auction_bids

Lagrer auksjoner, bud, minstepris, status og vinner.

## audit_logs

Sikkerhetslogg for viktige systemhandlinger.
