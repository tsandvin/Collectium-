# Collectium AI Developer Instructions

Du programmerer Collectium, en AI-basert plattform for samleobjekter.

## Overordnet mål

Bygg et sikkert, responsivt og skalerbart system for registrering, søk, analyse, verdsetting, auksjon og administrasjon av samleobjekter.

## Roller

Systemet skal støtte disse rollene:

- guest: kan se offentlig innhold
- member: kan registrere egne objekter og samlinger
- dealer: kan administrere objekter, kataloger, salg og auksjoner
- admin: kan administrere brukere, objekter og systemdata
- super_admin: full systemtilgang

## Frontend

Bruk React og Tailwind CSS.

Krav:

- Responsiv layout
- Sidebar på desktop
- Hamburger/offcanvas på mobil
- Topbar med søk, brukeravatar og handlinger
- Objektkort
- Detaljside for samleobjekt
- Filtre for kategori, år, land, konge/person, materiale, verdi, status og forhandler
- Slider kun på mobil der det er naturlig
- Hjul/scroll-funksjon på store filterfelt der det finnes mer enn 10 valg
- Dark mode-klargjort struktur

## Backend

Bruk PHP REST API.

Krav:

- Alle endepunkter skal autentisere bruker der det kreves
- Rollebasert tilgang
- Prepared statements mot MySQL
- Validering av input
- JSON-respons med tydelige statuskoder
- Loggføring av kritiske handlinger

## Database

Bruk MySQL.

Kjerneobjekter:

- users
- roles
- memberships
- dealers
- collectible_objects
- object_images
- object_logs
- object_categories
- object_valuations
- auctions
- auction_bids
- audit_logs

## Sikkerhet

- Ingen hemmelige nøkler i frontend
- Ingen API-nøkler i GitHub
- Bruk `.env` lokalt og `.env.example` i repository
- Sanitiser all input
- Valider filtyper ved bildeopplasting
- Bruk rate limiting på login og søk
- Loggfør endringer på objekter, bud, eierskap og medlemskap

## Kodeprinsipper

- Skriv ren, modulær kode
- Skill mellom layout, komponenter, API, database og logikk
- Ikke bland SQL direkte i frontend
- Ikke hardkod roller, bruk rollefelt fra database
- Kommenter kompleks forretningslogikk
- Lag små komponenter som kan gjenbrukes

## Før du lager kode

Kontroller alltid:

1. Hvilken modul funksjonen tilhører
2. Hvilken brukerrolle som skal ha tilgang
3. Hvilke tabeller som må leses eller skrives
4. Om handlingen skal loggføres
5. Hvordan funksjonen fungerer på mobil og desktop
