CREATE TABLE roles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE users (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  role_id INT NOT NULL,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255),
  oauth_provider VARCHAR(50),
  oauth_id VARCHAR(190),
  status ENUM('active','pending','blocked') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (role_id) REFERENCES roles(id)
);

CREATE TABLE memberships (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  plan_name VARCHAR(100) NOT NULL,
  status ENUM('active','trial','expired','cancelled') DEFAULT 'trial',
  starts_at DATE,
  ends_at DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE dealers (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  company_name VARCHAR(190) NOT NULL,
  organization_number VARCHAR(50),
  public_profile TEXT,
  approval_status ENUM('pending','approved','rejected') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE object_categories (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  parent_id BIGINT NULL,
  FOREIGN KEY (parent_id) REFERENCES object_categories(id)
);

CREATE TABLE collectible_objects (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  owner_user_id BIGINT,
  dealer_id BIGINT NULL,
  category_id BIGINT,
  title VARCHAR(255) NOT NULL,
  object_type VARCHAR(100),
  country VARCHAR(100),
  year_from INT,
  year_to INT,
  period_name VARCHAR(150),
  person_or_king VARCHAR(150),
  material VARCHAR(100),
  condition_grade VARCHAR(80),
  rarity_grade VARCHAR(80),
  description TEXT,
  provenance TEXT,
  status ENUM('draft','private','public','for_sale','in_auction','sold','archived') DEFAULT 'draft',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (owner_user_id) REFERENCES users(id),
  FOREIGN KEY (dealer_id) REFERENCES dealers(id),
  FOREIGN KEY (category_id) REFERENCES object_categories(id)
);

CREATE TABLE object_images (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  object_id BIGINT NOT NULL,
  image_url VARCHAR(500) NOT NULL,
  image_type ENUM('front','back','detail','certificate','other') DEFAULT 'other',
  sort_order INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (object_id) REFERENCES collectible_objects(id)
);

CREATE TABLE object_valuations (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  object_id BIGINT NOT NULL,
  valuation_amount DECIMAL(15,2) NOT NULL,
  currency CHAR(3) DEFAULT 'NOK',
  valuation_source VARCHAR(190),
  valuation_date DATE,
  kpi_adjusted_amount DECIMAL(15,2),
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (object_id) REFERENCES collectible_objects(id)
);

CREATE TABLE object_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  object_id BIGINT NOT NULL,
  user_id BIGINT,
  action VARCHAR(100) NOT NULL,
  details JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (object_id) REFERENCES collectible_objects(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE auctions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  object_id BIGINT NOT NULL,
  seller_user_id BIGINT NOT NULL,
  title VARCHAR(255) NOT NULL,
  start_price DECIMAL(15,2) NOT NULL,
  reserve_price DECIMAL(15,2),
  currency CHAR(3) DEFAULT 'NOK',
  starts_at DATETIME,
  ends_at DATETIME,
  status ENUM('draft','active','ended','cancelled') DEFAULT 'draft',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (object_id) REFERENCES collectible_objects(id),
  FOREIGN KEY (seller_user_id) REFERENCES users(id)
);

CREATE TABLE auction_bids (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  auction_id BIGINT NOT NULL,
  bidder_user_id BIGINT NOT NULL,
  bid_amount DECIMAL(15,2) NOT NULL,
  currency CHAR(3) DEFAULT 'NOK',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (auction_id) REFERENCES auctions(id),
  FOREIGN KEY (bidder_user_id) REFERENCES users(id)
);

CREATE TABLE audit_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT,
  action VARCHAR(150) NOT NULL,
  entity_type VARCHAR(100),
  entity_id BIGINT,
  ip_address VARCHAR(80),
  user_agent VARCHAR(255),
  details JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

INSERT INTO roles (name) VALUES
('guest'),
('member'),
('dealer'),
('admin'),
('super_admin');
