<?php

header('Content-Type: application/json; charset=utf-8');

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'];

if ($path === '/api/health' && $method === 'GET') {
    echo json_encode([
        'status' => 'ok',
        'app' => 'Collectium API'
    ]);
    exit;
}

http_response_code(404);
echo json_encode([
    'error' => 'Endpoint not found'
]);
