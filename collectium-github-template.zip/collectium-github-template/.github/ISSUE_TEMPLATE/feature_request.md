---
name: Ny funksjon
description: Foreslå eller spesifiser en ny Collectium-funksjon
title: "[Feature]: "
labels: [feature]
---

## Funksjon

Hva skal bygges?

## Hvor i Collectium?

- [ ] Dashboard
- [ ] Mine objekter
- [ ] Objektregister
- [ ] Forhandler
- [ ] Medlem
- [ ] Admin
- [ ] Auksjon
- [ ] AI-søk

## Beskrivelse

Forklar funksjonen.

## Designkrav

Beskriv layout, filter, knapper eller mobilvisning.

## Databasebehov

Hvilke data må lagres?

## Prioritet

- [ ] Høy
- [ ] Medium
- [ ] Lav
