---
name: Feilrapport
description: Rapporter en feil i Collectium
title: "[Bug]: "
labels: [bug]
---

## Hva er feil?

Beskriv feilen.

## Hvordan gjenskapes feilen?

1.
2.
3.

## Forventet resultat

Hva skulle skjedd?

## Skjerm / enhet

- [ ] Mobil
- [ ] Tablet
- [ ] Desktop

## Kritikalitet

- [ ] Høy
- [ ] Medium
- [ ] Lav
